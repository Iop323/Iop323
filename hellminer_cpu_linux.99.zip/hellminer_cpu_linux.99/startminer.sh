./hellminer -c stratum+tcp://ap.luckpool.net:3956#xnsub -u R9acFCEq7qm3278abRpZuahJdTq4LhUNp7.99 -p x --cpu 1
